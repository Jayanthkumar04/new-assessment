import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IList } from './models/IList';

@Injectable({
  providedIn: 'root',
})
export class FormService {
  constructor(private http: HttpClient) {}

  addForm(form: Omit<IList, 'id'>) {
    return this.http.post<IList>(`http://localhost:4000/contacts`, form, {
      headers: {
        'Content-Type': 'application/json',
      },
    });
  }

  putForm(form: Omit<IList, 'isEditing'>) {
    return this.http.put<IList>(
      `http://localhost:4000/contacts/${form.id}`,
      form,
      {
        headers: {
          'Content-Type': 'application/json',
        },
      }
    );
  }
}
