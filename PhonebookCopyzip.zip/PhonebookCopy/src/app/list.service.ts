import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IList } from './models/IList';

@Injectable({
  providedIn: 'root',
})
export class ListService {
  constructor(private http: HttpClient) {}

  getList() {
    return this.http.get<IList[]>(`http://localhost:4000/contacts`);
  }

  deleteContact(id: string) {
    return this.http.delete<{}>(`http://localhost:4000/contacts/${id}`);
  }
}
