import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { FormService } from '../form.service';
import { Router } from '@angular/router';
import { IList } from '../models/IList';
@Component({
  selector: 'app-form',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './form.component.html',
  styleUrl: './form.component.scss',
})
export class FormComponent {
  constructor(private formService: FormService, private router: Router) {}

  onSubmit(form: NgForm) {
    const newItem = {
      name: form.value.name,
      number: form.value.number,
    } as Omit<IList, 'id'>;
    this.formService.addForm(newItem).subscribe({
      next: (data) => {
        console.log(data);
        alert('data added successfully');
        this.router.navigate(['/']);
        window.location.reload();
      },
    });
  }
}
