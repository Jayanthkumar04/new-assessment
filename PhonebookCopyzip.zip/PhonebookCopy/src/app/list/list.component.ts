import { Component, OnInit } from '@angular/core';
import { ListService } from '../list.service';
import { IList } from '../models/IList';
import { CommonModule } from '@angular/common';
import { FormComponent } from '../form/form.component';
import { NgModel, FormsModule } from '@angular/forms';
import { FormService } from '../form.service';

@Component({
  selector: 'app-list',
  standalone: true,
  imports: [CommonModule, FormComponent, FormsModule],
  templateUrl: './list.component.html',
  styleUrl: './list.component.scss',
})
export class ListComponent implements OnInit {
  list: IList[] = [];

  constructor(
    private listService: ListService,
    private formService: FormService
  ) {}

  ngOnInit(): void {
    this.getList();
  }

  getList() {
    this.listService.getList().subscribe({
      next: (data) => {
        this.list = data;
      },
    });
  }

  deleteContact(l: IList) {
    console.log('inside');
    if (confirm('r u sure u want to delete')) {
      this.listService.deleteContact(l.id).subscribe({
        next: (data) => {
          alert('delted successfully');
          window.location.reload();
        },
      });
    }
  }

  editContact(l: IList) {
    l.isEditing = true;
  }

  updateContact(editForm: IList) {
    const editedForm = {
      name: editForm.name,
      id: editForm.id,
      number: editForm.number,
      isEditing: (editForm.isEditing = false),
    } as Omit<IList, 'isEditing'>;
    this.formService.putForm(editForm).subscribe({
      next: (data) => {
        alert('data edited successfully');
        console.log(data);
        window.location.reload();
      },
    });
  }
}
