interface IList {
  id: string;
  name: string;
  number: string;
  isEditing: boolean;
}
export type { IList };
